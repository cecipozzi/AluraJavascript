var numeroSecreto = parseInt(Math.random() * 1000 + 1);

//alert(numeroSecreto);
while (numeroSecreto != numeroIngresado) {
  var numeroIngresado = prompt("Ingresa un número entre 1 y 1000");

  if (numeroSecreto == numeroIngresado) {
    alert("Correctooo!");
  } else if (numeroSecreto > numeroIngresado) {
    alert("Error, el número secreto es MAYOR que el número ingresado");
  } else if (numeroSecreto < numeroIngresado) {
    alert("Error, el número secreto es MENOR que el número ingresado");
  }
}
