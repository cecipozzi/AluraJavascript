# Clase 02 - Mentalista

A Pen created on CodePen.io. Original URL: [https://codepen.io/ceciliapozzi/pen/wvZrjQO](https://codepen.io/ceciliapozzi/pen/wvZrjQO).

