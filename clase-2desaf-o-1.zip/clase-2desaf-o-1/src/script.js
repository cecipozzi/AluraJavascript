var numeroSecreto = parseInt(Math.random() * 1000 + 1);

var nroIntentos = 0;

//alert(numeroSecreto);
while (numeroSecreto != numeroIngresado) {
  if (nroIntentos != 0) {
    //alert("Intento número " + nroIntentos);
  }

  var numeroIngresado = prompt("Ingresa un número entre 1 y 1000");

  if (numeroSecreto == numeroIngresado) {
    alert("¡Correctooo! ¡El número secreto es: " + numeroSecreto + "!");
  } else if (numeroSecreto > numeroIngresado) {
    alert(
      "Error en el intento número " +
        (nroIntentos + 1) +
        ", el número secreto es MAYOR que el número ingresado. ¡Suerte en el intento número " +
        (nroIntentos + 2) +
        "!"
    );
  } else if (numeroSecreto < numeroIngresado) {
    alert(
      "Error en el intento número " +
        (nroIntentos + 1) +
        ", el número secreto es MENOR que el número ingresado. ¡Suerte en el intento número " +
        (nroIntentos + 2) +
        "!"
    );
  }
  nroIntentos += 1;
}
