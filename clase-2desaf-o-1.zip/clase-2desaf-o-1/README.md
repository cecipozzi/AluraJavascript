# Clase 2 - Desafío 1

A Pen created on CodePen.io. Original URL: [https://codepen.io/ceciliapozzi/pen/yLrzENJ](https://codepen.io/ceciliapozzi/pen/yLrzENJ).

