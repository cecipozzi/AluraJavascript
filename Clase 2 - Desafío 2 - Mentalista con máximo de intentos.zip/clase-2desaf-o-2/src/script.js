var juego = prompt("¿Tenés ganas de probar suerte? ¿Si o no?");

if (juego == "si") {
  var numeroSecreto = parseInt(Math.random() * 1000 + 1);
  var nroIntentos = 0;
  var numeroIngresado;
  var maxIntentos = 10;

  console.log(numeroSecreto);

  while (nroIntentos < maxIntentos) {
    numeroIngresado = prompt(
      "Ingresa un número entre 1 y 1000. Tienes " +
        maxIntentos +
        " intentos en total. ¡Mucha suerte!"
    );
    nroIntentos += 1;
    var intentosRest = maxIntentos - nroIntentos;

    if (numeroSecreto == numeroIngresado) {
      alert(
        "¡Correctooo! ¡El número secreto es: " +
          numeroSecreto +
          " y lo lograste en " +
          nroIntentos +
          " intentos!"
      );
      break;
    } else if (numeroSecreto > numeroIngresado) {
      alert(
        "Error en el intento número " +
          nroIntentos +
          ", el número secreto es MAYOR que el número ingresado. ¡Suerte en el intento número " +
          (nroIntentos + 1) +
          "! Te quedan " +
          intentosRest +
          " intentos."
      );
    } else {
      alert(
        "Error en el intento número " +
          nroIntentos +
          ", el número secreto es MENOR que el número ingresado. ¡Suerte en el intento número " +
          (nroIntentos + 1) +
          "! Te quedan " +
          intentosRest +
          " intentos."
      );
    }
  }
  if (nroIntentos == maxIntentos) {
    alert(
      "Agotaste tus " +
        maxIntentos +
        " intentos, el  número secreto era " +
        numeroSecreto
    );
  }
}
