var nombreUsuario = "Cecilia";
var valorAnosLuz = 250;
var anosLuzEnKm = 9460800000000;
var anosLuzEnMetros = 9460800000000000;

var valorEnKm = valorAnosLuz * anosLuzEnKm;
var valorEnMetros = valorAnosLuz * anosLuzEnMetros;

alert(
  "¡Hola " +
    nombreUsuario +
    "! " +
    valorAnosLuz +
    " años luz, corresponden a " +
    valorEnKm +
    " kilómetros y a " +
    valorEnMetros +
    " metros."
);
