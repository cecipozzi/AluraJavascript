var nombreUsuario = "Cecilia";
var tempCelsius = 30;
var tempFarenheit = (tempCelsius * 9) / 5 + 32;
var tempKelvin = tempCelsius + 273.15;

alert(
  "Hola " +
    nombreUsuario +
    ", la temperatura de " +
    tempCelsius +
    " grados Celsius, corresponde a " +
    tempFarenheit +
    " grados Farenheit y a " +
    tempKelvin +
    " grados Kelvin"
);
