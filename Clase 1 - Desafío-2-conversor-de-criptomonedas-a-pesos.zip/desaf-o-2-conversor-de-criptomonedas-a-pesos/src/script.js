var nombreUsuario = "Cecilia";
var valorBitcoin = 2;
var cotizacionBitcoin = 59790989.77;
var valorPesos = valorBitcoin * cotizacionBitcoin;

alert(
  "Hola " +
    nombreUsuario +
    ", el valor en Pesos argentinos de " +
    valorBitcoin +
    " BTC, es de $ " +
    valorPesos
);
