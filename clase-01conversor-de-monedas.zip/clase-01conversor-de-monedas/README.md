# Clase 01 - Conversor de monedas

A Pen created on CodePen.io. Original URL: [https://codepen.io/ceciliapozzi/pen/MWREELO](https://codepen.io/ceciliapozzi/pen/MWREELO).

El proyecto trata de un conversor de monedas en el cual, dado un valor en Dólares y ya fijada la cotización del momento, lo transforma en Pesos Argentinos