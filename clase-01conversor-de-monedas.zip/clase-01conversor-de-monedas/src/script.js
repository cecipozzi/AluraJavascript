var valorEnDolar = 155.5;

var cotizacionEnPesos = 857.24;

var valorEnPesos = valorEnDolar * cotizacionEnPesos;

var nombreUsuario = "Cecilia";

valorEnPesos = valorEnPesos.toFixed(2);

alert("Hola, " + nombreUsuario + "! El valor en pesos es: $ " + valorEnPesos);
